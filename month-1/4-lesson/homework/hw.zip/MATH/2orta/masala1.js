console.log(Math.floor(Math.random()*41+10));

