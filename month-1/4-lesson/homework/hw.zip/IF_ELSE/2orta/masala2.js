let a = 10, b = 10;

console.log(a == b ? "teng" : "teng emas")


