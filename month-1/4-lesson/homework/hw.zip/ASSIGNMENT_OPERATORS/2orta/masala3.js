let a = 5;

console.log((a *= 3, a += 10));
