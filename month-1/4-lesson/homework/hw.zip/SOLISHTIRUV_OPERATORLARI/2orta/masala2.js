let a = 10, b = "10";

console.log(`==: ${a == b} \n===: ${a===b}`)