let employee = {
  name: "Akbar",
  age: 20,
  position: "Junior"
};

let descriptors = Object.getOwnPropertyDescriptors(employee);
console.log(descriptors);