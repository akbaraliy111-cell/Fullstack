let settings = {};

Object.defineProperty(settings, "theme", {
  value: "dark", 
  writable: false, 
  enumerable: true,
  configurable: true
});

console.log(settings.theme);
settings.theme = "light";
console.log(settings.theme);