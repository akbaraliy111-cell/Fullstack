let user = {};

Object.defineProperties(user, {
  name: {
    value: "Akbar",
    enumerable: true  
  },
  age: {
    value: 25,
    enumerable: false 
  }
});

for (let key in user) {
  console.log(key); 
}