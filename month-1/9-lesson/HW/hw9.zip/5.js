let account = {};

Object.defineProperty(account, "balance", {
  value: 5000000,      
  writable: true,      
  enumerable: false,   
  configurable: true
});
