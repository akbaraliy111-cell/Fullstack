let person = {};
Object.defineProperties(person, {
  name: {
    value: "Akbar",
    writable: true,
    enumerable: true,
    configurable: true
  },
  age: {
    value: 25,
    writable: false,
    enumerable: true,
    configurable: false
  },
  password: {
    value: "1234",
    writable: false,
    enumerable: false,
    configurable: false
  }
});

let descriptors = Object.getOwnPropertyDescriptors(person);

console.table(descriptors);