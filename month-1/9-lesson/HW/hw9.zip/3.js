let book = {
  title: "JavaScript",
  author: "Akbar"
};

Object.defineProperty(book, "isbn", {
  value: "2020", 
  writable: false,        
  enumerable: true,         
  configurable: false       
});
