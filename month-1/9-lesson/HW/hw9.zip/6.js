let user = {};

Object.defineProperties(user, {
  name: {
    value: "Akbar",   
    writable: true,   
    enumerable: true, 
    configurable: true
  },
  age: {
    value: 25, 
    writable: true,
    enumerable: true,
    configurable: true
  },
  role: {
    value: "Admin", 
    writable: false,  
    enumerable: true,
    configurable: false
  }
});

console.log(user);