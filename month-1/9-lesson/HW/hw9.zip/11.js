let employee = {
  name: "Akbar",
  position: "Junior"
};

Object.defineProperty(employee, "salary", {
  value: 5000000,
  writable: false,   
  enumerable: false,  
  configurable: false  
});

employee.salary = 9999999;       
console.log(employee.salary);

console.log(Object.keys(employee)); 
for (let key in employee) {
  console.log(key);}

delete employee.salary;          
console.log(employee.salary);     

Object.defineProperty(employee, "salary", {
  writable: true 
});