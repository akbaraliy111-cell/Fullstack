let product = {};

Object.defineProperties(product, {
  name: {
    value: "Noutbuk",
    enumerable: true  
  },
  price: {
    value: 5000000,
    enumerable: true 
  },
  secretCode: {
    value: "ABC123",
    enumerable: false 
  }
});

console.log("Object.keys():")
console.log(Object.keys(product));

console.log("for...in:");
for (let key in product) {
  console.log(key); 
}

console.log("getOwnPropertyNames():");
console.log(Object.getOwnPropertyNames(product)); // ["name", "price", "secretCode"]