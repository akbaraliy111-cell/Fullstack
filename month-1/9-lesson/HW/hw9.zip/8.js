let user = {
  name: 'Vali',
  age: 20
};

Object.keys(user).forEach(key => {
  Object.defineProperty(user, key, {
    writable: false,    
    configurable: false 
  });
});