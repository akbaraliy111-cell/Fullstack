function isPrime(n) {
    if (n < 2) return false;
    for (let i = 2; i <= Math.sqrt(n); i++) {
        if (n % i === 0) return false;
    }
    return true;
}

const arr = [4, 6, 8, 7, 10];

console.log(arr.some(item => isPrime(item)));