const arr = ["aaaaa", "aaa", "aaaa"];

const newArr = arr.sort((a, b) => b.length - a.length)

console.log(newArr);