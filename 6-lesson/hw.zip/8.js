const arr = [12, [-1, 3], [21, -2]];
const arr1 = arr.flat(Infinity);
const count = arr1.reduce((acc, i) => i > 0 ? acc + 1 : acc, 0);

console.log(count); 