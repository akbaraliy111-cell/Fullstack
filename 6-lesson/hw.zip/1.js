const arr = [2,44,1,4,5,32,19,33,12];

const newArr = arr.sort((a, b) => b - a)

console.log(newArr);
