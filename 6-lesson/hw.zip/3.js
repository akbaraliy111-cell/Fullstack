const arr = ['ali', 'vali', 'ali'];
const unique = [];

for (let i of arr){
    if (!unique.includes(i)){
        unique.push(i);
    }
}
console.log(unique);