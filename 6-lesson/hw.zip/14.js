const arr = [`alibek`, 'li', `ai`];
const result = arr.reduce((acc, item) => acc + item.length, 0);
console.log(result);
