const arr = [1,2,3];
const oddeven = [];

for (let i of arr){
    if (i % 2 === 0){
        oddeven.push(`juft`);
    }
    else {
        oddeven.push(`toq`);
    }
}
console.log(oddeven);