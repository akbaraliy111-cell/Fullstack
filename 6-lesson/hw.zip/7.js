const arr = ['ali', 'vali', [[[[[[[[[[['salim']]]]]]]]]]]];
console.log(arr.flat(Infinity));

