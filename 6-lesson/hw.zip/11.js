const students = [45, 78 + 2, 92, 61, 85, 73, 95, 55, 88, 70];
const result = students.filter(item => item >= 80)

console.log(result);