const arr = [`Air`, `key`, `banana`, `apple`, `rice`];

const newArr = arr.map(item => item[0])

console.log(newArr);
