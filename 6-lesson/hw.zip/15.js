function onlyUnique(array){
    let result = array.filter(item => array.indexOf(item) === array.lastIndexOf(item))
    return result;
}
const arr = [1, 2, 3, 2, 4, 3, 5];
console.log(onlyUnique(arr));
