const arr = [1,2,3,4,5];
const avg = arr.reduce((acc, i) => acc + i, 0) / arr.length

console.log(avg);
