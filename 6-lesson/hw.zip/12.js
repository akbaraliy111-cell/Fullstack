const products = [
{ name: "Book", price: 50 },
{ name: "Phone", price: 500 }
];

let maxPrice = products[0]
for (let product of products){
    if (product.price > maxPrice.price) maxPrice = product
}

console.log(maxPrice);