const arr = [1,2,3,4,5];

const newArr = arr.reduce((acc, i) => acc *= i);

console.log(newArr);
