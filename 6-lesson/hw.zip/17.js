function findMax(arr){
    let obj = {};
    
    for (let item of arr){
        if (item in obj){
            obj[item] += 1;
        } else {
            obj[item] = 1;
        }
    }
    const maximal = Math.max(...Object.values(obj))
    return Object.keys(obj).find(key => key === maximal)
}

const arr = ['a', 'b', 'a', 'c', 'a', 'b'];
console.log(findMax(arr));