const arr = ['ali', 'vali', 'salim'];

const maxLen = Math.max(...arr.map(i => i.length));

const maxstring = arr.filter(i => i.length === maxLen);
console.log(maxstring);