const arr = ['ali', 'vali', 'salim'];
console.log(arr.join(", "));
